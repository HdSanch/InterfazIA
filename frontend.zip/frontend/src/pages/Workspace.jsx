import { useContext, useState } from "react";
import { ClassContext } from "../context/ClassContext";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import Navbar from "../components/Navbar";
import ChatBox from "../components/ChatBox";
import "../styles/main.css";

export default function Workspace() {
  const { docId, content, setContent, fileName } = useContext(ClassContext);
  const [isLoading, setIsLoading] = useState(false);
  const [activeAction, setActiveAction] = useState(null);
  const [notification, setNotification] = useState(null);
  const navigate = useNavigate();

  // Función para mostrar notificaciones
  const showNotification = (message, type = 'error') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  if (!docId) {
    return (
      <>
        <Navbar />
        <div className="workspace-empty">
          <div className="empty-icon">📄</div>
          <h3 className="empty-title">No hay documento cargado</h3>
          <p className="empty-description">
            Para comenzar a trabajar, debe cargar un documento académico en el sistema.
          </p>
          <button 
            className="empty-action-btn"
            onClick={() => navigate("/tema")}
          >
            Cargar Documento
          </button>
        </div>
      </>
    );
  }

  async function safeFetch(url) {
    try {
      const res = await fetch(url, { method: "POST" });
      const data = await res.json();

      if (data?.error?.code === 429) {
        showNotification("⚠️ Límite diario de la API alcanzado. Por favor, intente más tarde.", 'warning');
        return null;
      }

      return data;
    } catch (error) {
      showNotification("❌ Error de conexión con el servidor.", 'error');
      return null;
    }
  }

  async function generarResumen() {
    setIsLoading(true);
    setActiveAction('resumen');
    setContent('');
    
    try {
      const data = await safeFetch(
        `http://127.0.0.1:8000/documents/${docId}/summary`
      );
      if (data?.summary) {
        setContent(data.summary);
        showNotification("✅ Resumen generado correctamente", 'success');
      } else if (data !== null) {
        showNotification("❌ No se pudo generar el resumen", 'error');
      }
    } catch (error) {
      showNotification("❌ Error al generar el resumen", 'error');
    } finally {
      setIsLoading(false);
    }
  }

  async function generarPreguntas() {
    setIsLoading(true);
    setActiveAction('preguntas');
    setContent('');
    
    try {
      const data = await safeFetch(
        `http://127.0.0.1:8000/documents/${docId}/practice/generate?n=8`
      );
      if (data?.questions) {
        setContent(data.questions.join("\n\n"));
        showNotification("✅ Preguntas generadas correctamente", 'success');
      } else if (data !== null) {
        showNotification("❌ No se pudieron generar las preguntas", 'error');
      }
    } catch (error) {
      showNotification("❌ Error al generar las preguntas", 'error');
    } finally {
      setIsLoading(false);
    }
  }

  async function generarPlan() {
    setIsLoading(true);
    setActiveAction('plan');
    setContent('');
    
    try {
      const data = await safeFetch(
        `http://127.0.0.1:8000/documents/${docId}/study-plan`
      );
      if (data?.plan) {
        setContent(data.plan);
        showNotification("✅ Plan de estudio generado correctamente", 'success');
      } else if (data !== null) {
        showNotification("❌ No se pudo generar el plan de estudio", 'error');
      }
    } catch (error) {
      showNotification("❌ Error al generar el plan de estudio", 'error');
    } finally {
      setIsLoading(false);
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(content);
    showNotification("📋 Contenido copiado al portapapeles", 'success');
  };

  return (
    <>
      <Navbar />
      
      {/* NOTIFICACIONES FLOTANTES */}
      <AnimatePresence>
        {notification && (
          <motion.div
            className={`notification-toast ${notification.type}`}
            initial={{ opacity: 0, y: -50, x: '-50%' }}
            animate={{ opacity: 1, y: 20 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 0.3 }}
          >
            <div className="notification-content">
              {notification.message}
            </div>
            <button 
              className="notification-close"
              onClick={() => setNotification(null)}
            >
              ✕
            </button>
          </motion.div>
        )}
      </AnimatePresence>
      
      <div className="workspace-container">
        <div className="workspace-layout">
          {/* SIDEBAR */}
          <aside className="workspace-sidebar">
            <div className="sidebar-header">
              <div className="sidebar-title">Documento Actual</div>
              <div className="document-info">
                <div className="document-label">Archivo</div>
                <div className="document-name">{fileName}</div>
              </div>
            </div>

            <div className="sidebar-actions">
              <button 
                className={`sidebar-action-btn ${activeAction === 'resumen' ? 'active' : ''}`}
                onClick={generarResumen}
                disabled={isLoading}
              >
                <span className="action-icon">📝</span>
                Generar Resumen
              </button>

              <button 
                className={`sidebar-action-btn ${activeAction === 'preguntas' ? 'active' : ''}`}
                onClick={generarPreguntas}
                disabled={isLoading}
              >
                <span className="action-icon">❓</span>
                Generar Preguntas
              </button>

              <button 
                className={`sidebar-action-btn ${activeAction === 'plan' ? 'active' : ''}`}
                onClick={generarPlan}
                disabled={isLoading}
              >
                <span className="action-icon">📊</span>
                Plan de Estudio
              </button>
            </div>
          </aside>

          {/* MAIN CONTENT */}
          <main className="workspace-main">
            <div className="workspace-header">
              <h2>Espacio de Trabajo</h2>
            </div>

            <div className="workspace-content-area">
              {/* CONTENT DISPLAY */}
              <motion.div 
                className="content-display-card"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="content-display-header">
                  <div className="content-display-title">
                    {activeAction === 'resumen' && 'Resumen del Documento'}
                    {activeAction === 'preguntas' && 'Preguntas de Práctica'}
                    {activeAction === 'plan' && 'Plan de Estudio'}
                    {!activeAction && 'Contenido Generado'}
                  </div>
                  {content && !isLoading && (
                    <div className="content-actions">
                      <button 
                        className="content-action-icon"
                        onClick={copyToClipboard}
                        title="Copiar"
                      >
                        📋
                      </button>
                    </div>
                  )}
                </div>

                <div className="content-display-body">
                  {isLoading ? (
                    <div className="content-loading">
                      <div className="loading-spinner"></div>
                      <div className="loading-text">Procesando documento...</div>
                    </div>
                  ) : content ? (
                    <div className="content-text">{content}</div>
                  ) : (
                    <div className="content-placeholder">
                      <div className="placeholder-icon">📄</div>
                      <div className="placeholder-text">Sin contenido generado</div>
                      <div className="placeholder-hint">
                        Seleccione una acción en el panel lateral para comenzar
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>

              {/* CHAT SECTION */}
              <motion.div 
                className="workspace-chat-section"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="chat-header">
                  <div className="chat-title">
                    <span>💬</span>
                    Asistente Virtual
                  </div>
                </div>
                <ChatBox />
              </motion.div>
            </div>
          </main>
        </div>
      </div>
    </>
  );
}