import Navbar from "../components/Navbar";

export default function Resultados() {
  return (
    <>
      <Navbar />
      <div style={{ padding: "40px" }}>
        <h2>Resultados</h2>

        <p><strong>Nivel alcanzado:</strong> Medio</p>

        <p>
          Se recomienda reforzar el tema con ejemplos adicionales
          antes de avanzar al siguiente nivel.
        </p>
      </div>
    </>
  );
}
